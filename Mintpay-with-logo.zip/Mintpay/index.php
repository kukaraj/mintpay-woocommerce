<?php
/*
Plugin Name: Mintpay
Plugin URI: https://www.mintpay.lk
Description: WooCommerce payment plugin of Mintpay payment gateway. Sri Lanka's first buy now pay later platform, that allows consumers to split their payment into 3 interst-free installments.
Version: 1.0.0
Author: Algoredge (Private) Limited
Author URI: https://www.mintpay.lk
*/

add_action('plugins_loaded', 'woocommerce_gateway_mintpay_init', 0);
define('mintpay_IMG', WP_PLUGIN_URL . "/" . plugin_basename(dirname(__FILE__)) . '/assets/img/');

function woocommerce_gateway_mintpay_init() {
	if ( !class_exists( 'WC_Payment_Gateway' ) ) return;

	if (!session_id()) {
		 session_start();
	}	

	/**
 	 * Gateway class
 	 */
	class WC_Gateway_mintpay extends WC_Payment_Gateway {

	     /**
         * Make __construct()
         **/	
		public function __construct(){
			
			$this->id 					= 'mintpay'; // ID for WC to associate the gateway values
            //$this->icon 				= WP_PLUGIN_URL . "/" . plugin_basename(dirname(__FILE__ )) . '/assets/img/logo.png';
			$this->method_title 		= "Mintpay"; // Gateway Title as seen in Admin Dashboad
			$this->method_description	= "Sri Lanka's first buy now pay later platform, that allows consumers to split their payment into 3 interst-free installments.";
			$this->has_fields 			= false; // Inform WC if any fileds have to be displayed to the visitor in Frontend 
			
			$this->init_form_fields();	// defines your settings to WC
			$this->init_settings();		// loads the Gateway settings into variables for WC

			$this->title 		= '<svg 
			id="Layer_1" 
			style="width:120px; position: relative;top: 10px;"
			data-name="Layer 1" 
			xmlns="http://www.w3.org/2000/svg" 
			width="150" 
			viewBox="0 0 301 78.49"> 
			<defs>
			<style>.cls-1{fill:#021b33}.cls-2{fill:#9cc1da}</style>
			</defs>
			<title>Mintpay</title> 
			<path class="cls-1" d="M101.43,62.78H93.75l8-43.72h7.69Zm5.72-50.32a4,4,0,0,1-3-1.34,5.62,5.62,0,0,1-1.27-4A7.86,
			7.86,0,0,1,104.51,2a4.71,4.71,0,0,1,3.72-2,4,4,0,0,1,3,1.38,5.7,5.7,0,0,1,1.3,4.05,7.59,7.59,
			0,0,1-1.65,5.06A4.83,4.83,0,0,1,107.15,12.46Z" /> 
			<path class="cls-1" d="M118.65,20.9A54,54,0,0,1,124.46,19a27.52,27.52,0,0,1,7.15-.88q5.84,0,8.58,3.76T142.92,32a33.35,
			33.35,0,0,1-.22,3.72q-.22,2-.54,4.05l-4.19,23h-7.68l3.93-21.9q.32-1.84.64-3.76a29.26,29.26,0,0,
			0,.38-3.68,9.18,9.18,0,0,0-1-4.85q-1.11-1.92-4.35-1.92a13.17,13.17,0,0,0-4.7.75l-6.37,35.36H111Z" /> 
			<path class="cls-1" d="M156,7.52l8-1.67-2.43,13.21h10.88l-1.52,8.36H160l-3.18,17.3q-.31,1.84-.43,3.05a22.16,22.16,0,0,
			0-.12,2.21,12,12,0,0,0,.16,2,4.16,4.16,0,0,0,.63,1.67,3.52,3.52,0,0,0,1.4,1.17,5.68,5.68,0,0,0,
			2.51.46,9.48,9.48,0,0,0,3.3-.59,20.09,20.09,0,0,0,2.79-1.25l.57,8.11A21.17,21.17,0,0,1,164,
			63.11a16.27,16.27,0,0,1-5.21.75q-5.46,0-7.81-3.13t-2.35-8.57a39.64,39.64,0,0,1,.22-4.14q.22-2.13.67-4.56Z" /> 
			<path class="cls-2" d="M217.49,41.13a30.64,30.64,0,0,1-1.3,9.11,20.62,20.62,0,0,1-3.8,7.19,17.27,17.27,0,0,1-6.14,4.68,
			19.71,19.71,0,0,1-8.32,1.67,20.19,20.19,0,0,1-6.64-1A20.94,20.94,0,0,1,187,60.86V78.24h-7.77V20.65q2.76-.67,
			6.9-1.46a51.24,51.24,0,0,1,9.57-.79,24.36,24.36,0,0,1,9,1.59,19.36,19.36,0,0,1,6.85,4.51,20,20,0,0,1,
			4.39,7.15A27.44,27.44,0,0,1,217.49,41.13Zm-8.11,0q0-7.61-3.76-11.7a13,13,0,0,0-10-4.1,45.85,45.85,0,0,
			0-5.48.25,22.24,22.24,0,0,0-3.13.58V53.58a15.92,15.92,0,0,0,4.1,2.26,15.39,15.39,0,0,0,5.85,1.09,12.5,
			12.5,0,0,0,5.73-1.21,10.5,10.5,0,0,0,3.89-3.34,14.14,14.14,0,0,0,2.17-5A27.59,27.59,0,0,0,209.39,41.13Z" /> 
			<path class="cls-2" d="M240.82,18.22a22.54,22.54,0,0,1,7.9,1.21,12.82,12.82,0,0,1,5.18,3.43,13,13,0,0,1,2.8,5.27,25.49,25.49,
			0,0,1,.84,6.73V62l-2.8.46q-1.8.29-4.05.54t-4.89.46q-2.63.21-5.22.21a28.62,28.62,0,0,1-6.77-.75,15.16,
			15.16,0,0,1-5.35-2.38,10.91,10.91,0,0,1-3.51-4.31,15.07,15.07,0,0,1-1.25-6.44,12.39,12.39,0,0,1,1.46-6.19,
			11.67,11.67,0,0,1,4-4.18A18.42,18.42,0,0,1,235,37.12a31.88,31.88,0,0,1,7-.75q1.17,0,2.42.13t2.38.33l2,.38,
			1.17.25V35.28a17.49,17.49,0,0,0-.42-3.8,8.73,8.73,0,0,0-1.5-3.34,7.62,7.62,0,0,0-3-2.34,11.63,11.63,0,0,
			0-4.89-.88,36.75,36.75,0,0,0-6.73.54,23.7,23.7,0,0,0-4.3,1.13l-.92-6.44a24,24,0,0,1,5-1.3A43.3,43.3,0,0,1,
			240.82,18.22Zm.67,39q2.76,0,4.89-.13a21.31,21.31,0,0,0,3.55-.46v-13a10,10,0,0,0-2.72-.71,30.26,30.26,0,0,
			0-4.56-.29,29.41,29.41,0,0,0-3.72.25,11.48,11.48,0,0,0-3.59,1,7.69,7.69,0,0,0-2.72,2.17,5.7,5.7,0,0,0-1.09,
			3.64q0,4.18,2.67,5.81A13.92,13.92,0,0,0,241.48,57.18Z" /> 
			<path class="cls-2" d="M262.55,70.89a14.8,14.8,0,0,0,2.38.79,11.53,11.53,0,0,0,2.88.38A11.32,11.32,0,0,0,275,70a17.65,17.65,0,0,0,
			4.68-6.65q-5.27-10-9.82-21.27a184.65,184.65,0,0,1-7.56-22.78h8.36q.92,3.76,2.21,8.11t2.88,8.94q1.59,4.6,3.43,
			9.2T283,54.42q3.18-8.78,5.52-17.39T293,19.31h8q-3,12.29-6.69,23.61t-7.94,21.19a44.73,44.73,0,0,1-3.47,6.48,
			19.61,19.61,0,0,1-4,4.47A14.52,14.52,0,0,1,274,77.66a20.89,20.89,0,0,1-6.14.84,15.51,15.51,0,0,
			1-1.92-.13c-.67-.08-1.32-.2-2-.33s-1.23-.29-1.76-.46a8.52,8.52,0,0,1-1.13-.42Z" /> 
			<path class="cls-1" d="M25,50.56a50.36,50.36,0,0,0,9.37-11.93c-1.09,1.08-4,1.53-4,1.53,2.27-1.6,3.47-3.59,5.08-5.85.36-.5,4.67-7.57,
			4.7-7.57-3,1.36-4.38,1.86-4.38,1.86,2.06-4.37,7.62-9.49,7.62-9.5-12.08,3-17.65,15-22,25.38-.65,1.56-1.31,3.12-2.11,
			4.61C15.41,56.36,8.06,60.79.18,62.64c1.12.07,7.33.45,10.34-.07a20.81,20.81,0,0,0,6.23-1.76c4.57-2.39,7.79-6.42,
			10.47-10.7A10.77,10.77,0,0,1,25,50.56Z" /> 
			<path class="cls-1" d="M19.32,49.1c.8-1.49,1.46-3.05,2.11-4.61,4.35-10.38,9.93-22.4,22-25.38h0c-9.16-2-16.35,4.06-16.35,
			4.06-.39-1.31.71-3.12.71-3.12-4.54,2.07-7.2,6.54-9.09,11-1-.46-.8-.87-.59-2.72-2.22,4.05-2.9,8-3.8,12.6a4.27,
			4.27,0,0,1-.71-2.76s-3.1,9.55-3.74,14.5c-.08.64-.63-.78-.63-.78a13.67,13.67,0,0,1-.21-2,18.93,18.93,0,0,0-2.1,
			3.68,26.56,26.56,0,0,1-1.55,3.06c-1.16,2.17-3.14,4.92-5.39,6H.18C8.06,60.79,15.41,56.36,19.32,49.1Z" /> 
			<path class="cls-1" d="M51.19,50.56a50.36,50.36,0,0,0,9.37-11.93c-1.09,1.08-4,1.53-4,1.53,2.27-1.6,3.47-3.59,5.08-5.85.36-.5,4.67-7.57,
			4.7-7.57C63.41,28.1,62,28.6,62,28.6c2.06-4.37,7.62-9.49,7.62-9.5-12.08,3-17.65,15-22,25.38C47,46,46.32,47.61,
			45.51,49.1,41.6,56.36,34.26,60.79,26.37,62.64c1.12.07,7.33.45,10.34-.07a20.81,20.81,0,0,0,6.23-1.76c4.57-2.39,
			7.79-6.42,10.47-10.7A10.77,10.77,0,0,1,51.19,50.56Z" /> 
			<path class="cls-1" d="M45.51,49.1c.8-1.49,1.46-3.05,2.11-4.61,4.35-10.38,9.93-22.4,22-25.38h0c-9.16-2-16.35,4.06-16.35,4.06C52.89,21.86,
			54,20,54,20c-4.54,2.07-7.2,6.54-9.09,11-1-.46-.8-.87-.59-2.72-2.22,4.05-2.9,8-3.8,12.6a4.27,4.27,0,0,
			1-.71-2.76s-3.1,9.55-3.74,14.5c-.08.64-.63-.78-.63-.78a13.67,13.67,0,0,1-.21-2,18.93,18.93,0,0,0-2.1,3.68,26.56,
			26.56,0,0,1-1.55,3.06c-1.16,2.17-3.14,4.92-5.39,6h.18C34.26,60.79,41.6,56.36,45.51,49.1Z" /> 
			<path class="cls-1" d="M77.19,50.56a50.36,50.36,0,0,0,9.37-11.93c-1.09,1.08-4,1.53-4,1.53,2.27-1.6,3.47-3.59,5.08-5.85.36-.5,4.67-7.57,
			4.7-7.57C89.41,28.1,88,28.6,88,28.6c2.06-4.37,7.62-9.49,7.62-9.5-12.08,3-17.65,15-22,25.38C73,46,72.31,
			47.61,71.51,49.1,67.6,56.36,60.26,60.79,52.37,62.64c1.12.07,7.33.45,10.34-.07a20.81,20.81,0,0,0,6.23-1.76c4.57-2.39,
			7.79-6.42,10.47-10.7A10.77,10.77,0,0,1,77.19,50.56Z" /> 
			<path class="cls-1" d="M71.51,49.1c.8-1.49,1.46-3.05,2.11-4.61,4.35-10.38,9.93-22.4,22-25.38h0c-9.16-2-16.35,4.06-16.35,4.06C78.88,21.86,
			80,20,80,20c-4.54,2.07-7.2,6.54-9.09,11-1-.46-.8-.87-.59-2.72-2.22,4.05-2.9,8-3.8,12.6a4.27,4.27,0,0,1-.71-2.76s-3.1,
			9.55-3.74,14.5c-.08.64-.63-.78-.63-.78a13.67,13.67,0,0,1-.21-2,18.93,18.93,0,0,0-2.1,3.68,26.56,26.56,0,0,1-1.55,
			3.06c-1.16,2.17-3.14,4.92-5.39,6h.18C60.26,60.79,67.6,56.36,71.51,49.1Z" /> 
			</svg>';
			$this->description 	=  "<p>Split your bill into 3, interest-free installments.<br/>
            Don’t have a Mintpay account yet? <a href='https://app.mintpay.lk/signup/' target='_blank'><u>Click here</u></a> to sign up now.<br/>T&C applies</p>";
            $this->merchant_id 		= $this->get_option( 'merchant_id' );
            $this->merchant_secret 	= $this->get_option( 'merchant_secret');
            $this->test_mode        = 'yes' === $this->get_option( 'test_mode' );
	
            $this->msg['message']	= '';
            $this->msg['class'] 	= '';
			
			add_action('init', array(&$this, 'check_mintpay_response'));
            add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'check_mintpay_response')); //update for woocommerce >2.0

            if ( version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
                    add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) ); //update for woocommerce >2.0
                 } else {
                    add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) ); // WC-1.6.6
                }
            add_action('woocommerce_receipt_mintpay', array(&$this, 'receipt_page'));

		} //END-__construct
		
        /**
         * Initiate Form Fields in the Admin Backend
         **/
		function init_form_fields(){

			$this->form_fields = array(
				// Activate the Gateway
				'enabled' => array(
					'title' 		=> __('Enable', 'woo_mintpay'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Enable mintpay gateway', 'woo_mintpay'),
					'default' 		=> 'yes',
					'description' 	=> 'Show mintpay as a payment option at checkout',
					'desc_tip' 		=> true
				),

				// Activate Test mode
				'test_mode' => array(
					'title' 		=> __('Test Mode', 'woo_mintpay'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Enable test mode', 'woo_mintpay'),
					'default' 		=> 'yes',
					'description' 	=> 'Test mintpay payment gateway in sandbox environment',
					'desc_tip' 		=> true
				),

				// LIVE Key-ID
      			'merchant_id' => array(
					'title' 		=> __('Merchant ID', 'woo_mintpay'),
					'type' 			=> 'text',
					'description' 	=> __('Your mintpay Merchant ID'),
					'desc_tip' 		=> true
				),
  				// LIVE Key-Secret
    			'merchant_secret' => array(
					'title' 			=> __('Merchant Secret', 'woo_mintpay'),
					'type' 			=> 'text',
					'description' 	=> __('Your mintpay Merchant Secret'),
					'desc_tip' 		=> true
                ),
			);

		} //END-init_form_fields
		
        /**
         * Admin Panel Options
         * - Show info on Admin Backend
         **/
		public function admin_options(){
			echo '<h3>'.__('Mintpay', 'woo_mintpay').'</h3>';
			echo '<p>'.__("WooCommerce payment plugin of Mintpay payment gateway. Sri Lanka's first buy now pay later platform, that allows consumers to split their payment into 3 interst-free installments").'</p>';
			echo '<table class="form-table">';
			// Generate the HTML For the settings form.
			$this->generate_settings_html();
			echo '</table>';
		} //END-admin_options

        /**
         *  There are no payment fields, but we want to show the description if set.
         **/
		function payment_fields(){
			if( $this->description ) {
				echo wpautop( wptexturize( $this->description ) );
			}
		} //END-payment_fields
		
        /**
         * Receipt Page
         **/
		function receipt_page($order){
			echo '<p><strong>' . __('Thank you for your order.', 'woo_mintpay').'</strong><br/>' . __('The payment page will open soon.', 'woo_mintpay').'</p>';
			echo $this->generate_mintpay_form($order);
		} //END-receipt_page



    
        /**
         * Generate button link
         **/
		function generate_mintpay_form($order_id){
			global $woocommerce;

			$order = wc_get_order( $order_id );

			$merchant_id = $this->merchant_id;
			$merchant_secret = $this->merchant_secret;
			$amount = $order->get_total();

			$success_hash = hash_hmac('sha256', $merchant_id . sprintf("%.02f", round($amount, 2)) . $order_id, $merchant_secret);
			$fail_hash = hash_hmac('sha256', $order_id, $merchant_secret);


		  	$_SESSION['order_id'] = $order_id;
			
			$redirect_url = $order->get_checkout_order_received_url();
			
			$notify_url = "";
			// Redirect URL : For WooCoomerce 2.0
			if ( version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				$notify_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
			}

			$success_url = $notify_url . '&hash=' .  base64_encode($success_hash);
			$fail_url = $notify_url . '&hash=' .  base64_encode($fail_hash);


			if ($this->test_mode){
				$api_url = "https://dev.mintpay.lk/user-order/api/";
				$form_url = "https://dev.mintpay.lk/user-order/login/";
			} else {
				$api_url = "https://app.mintpay.lk/user-order/api/";
				$form_url = "https://app.mintpay.lk/user-order/login/";
			}

            foreach($order->get_items() as $item_id => $item) {

            	$order_items[] = array(
            		'name'         => $item->get_name(),
                    'product_id'   => $item->get_product_id(),
                    'sku'          => $item->get_type(),
                    'quantity'     => $item->get_quantity(),
                    'unit_price'   => $item->get_total(),
                    'created_date' => "2001-10-01 01:10:01",
                    'updated_date' => "2001-10-01 01:10:01",
                    'discount'     => "0.00"
                );
            }

			$postData = [
				'merchant_id'           => $merchant_id,
				'order_id'              => $order_id,
				'total_price'           => $amount,
				'discount'              => $order ->get_total_discount(),
                'customer_id'           => $order->get_customer_id(),
                'customer_email'        => $order->get_billing_email(),
                'customer_telephone'    => $order->get_billing_phone(),
                'ip'                    => $order->get_customer_ip_address(),
                'x_forwarded_for'       => $order->get_customer_ip_address(),
                'delivery_street'       => $order->get_billing_address_1() . $order->get_billing_address_2(),
                'delivery_region'       => $order->get_billing_city(),
                'delivery_postcode'     => $order->get_billing_postcode(),
                'cart_created_date'     => date_format($order->get_date_created(),"Y-m-d H:i:s"),
                'cart_updated_date'     => date_format($order->get_date_modified(),"Y-m-d H:i:s"),
                'success_url'           => $success_url,
                'fail_url'              => $fail_url,
                'products'              => $order_items,
			];
            
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $api_url);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));  //Post Fields
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			$headers = [
				'Authorization: Token '. $merchant_secret,
				'Content-Type: application/json',
			];

			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			$server_output = curl_exec ($ch);
			$mintpayRequestData = json_decode($server_output, true);

			curl_close ($ch);

			if(isset($mintpayRequestData['message']) && $mintpayRequestData['message']=='Success'){
			
			return '<form action="'. $form_url .'"method="post" id="mintpay_payment_form">
			<input type="hidden" name="purchase_id" value="'.$mintpayRequestData['data'].'" >
			<input type="submit" class="button-alt" id="submit_mintpay_payment_form" value="'.__('Pay via mintpay', 'woo_mintpay').'" /> <a class="button cancel" href="'.$order->get_cancel_order_url().'">'.__('Cancel order &amp; restore cart', 'woo_mintpay').'</a>
				<script type="text/javascript">
				jQuery(function(){
				jQuery("body").block({
					message: "'.__('Thanks for your order! We are now redirecting you to Mintpay payment gateway to make the payment.', 'woo_mintpay').'",
					overlayCSS: {
						background		: "#fff",
						opacity			: 0.8
					},
					css: {
						padding			: 20,
						textAlign		: "center",
						color			: "#333",
						border			: "1px solid #eee",
						backgroundColor	: "#fff",
						cursor			: "wait",
						lineHeight		: "32px"
					}
				});
				jQuery("#submit_mintpay_payment_form").click();});
				</script>
			</form>';

		}

		else{
			return wp_redirect( wc_get_cart_url() );
		}
		
		} //END-generate_mintpay_form


		function check_mintpay_response(){
			global $woocommerce;

			if(isset($_GET['key']) && isset($_GET['hash'])){

				if (isset($_SESSION['order_id'])){
					$order = wc_get_order( $_SESSION['order_id'] );

					$post_success_hash = hash_hmac('sha256', $this->merchant_id . sprintf("%.02f", round($order->get_total(), 2)) . $_SESSION['order_id'],  $this->merchant_secret);

					$post_failed_hash = hash_hmac('sha256', $_SESSION['order_id'],  $this->merchant_secret);

					if ( base64_decode($_GET['hash']) == $post_success_hash){
						$order->payment_complete();
						$woocommerce->cart->empty_cart();
						wp_redirect( $order->get_checkout_order_received_url() );
					}

					else if ( base64_decode($_GET['hash']) == $post_failed_hash){
						$cancelled_text = "Payment failed.";
						$order->update_status( 'cancelled', $cancelled_text );
						wp_redirect( $order->get_cancel_order_url() );
					} 
					else{
						$cancelled_text = "Suspicious response.";
						$order->update_status( 'cancelled', $cancelled_text );
						$woocommerce->cart->empty_cart();
						wp_redirect( $order->get_cancel_order_url() );
						//return echo $post_hash;
					}

				}

				else{
					wp_redirect( wc_get_cart_url() );
				}
			}

			else{
					wp_redirect( wc_get_cart_url() );
			}
		}
				

		
        /**
         * Process the payment and return the result
         **/
        function process_payment($order_id){
			global $woocommerce;
            $order = new WC_Order($order_id);
			
			if ( version_compare( WOOCOMMERCE_VERSION, '2.1.0', '>=' ) ) { // For WC 2.1.0
			  	$checkout_payment_url = $order->get_checkout_payment_url( true );
			} else {
				$checkout_payment_url = get_permalink( get_option ( 'woocommerce_pay_page_id' ) );
			}

			return array(
				'result' => 'success', 
				'redirect' => add_query_arg(
					'order', 
					$order->id, 
					add_query_arg(
						'key', 
						$order->order_key, 
						$checkout_payment_url						
					)
				)
			);
		} //END-process_payment


        /**
         * Get Page list from WordPress
         **/
		function mintpay_get_pages($title = false, $indent = true) {
			$wp_pages = get_pages('sort_column=menu_order');
			$page_list = array();
			if ($title) $page_list[] = $title;
			foreach ($wp_pages as $page) {
				$prefix = '';
				// show indented child pages?
				if ($indent) {
                	$has_parent = $page->post_parent;
                	while($has_parent) {
                    	$prefix .=  ' - ';
                    	$next_page = get_post($has_parent);
                    	$has_parent = $next_page->post_parent;
                	}
            	}
            	// add to page list array array
            	$page_list[$page->ID] = $prefix . $page->post_title;
        	}
        	return $page_list;
		} //END-mintpay_get_pages

	} //END-class
	
	/**
 	* Add the Gateway to WooCommerce
 	**/
	function woocommerce_add_gateway_mintpay_gateway($methods) {
		$methods[] = 'WC_Gateway_mintpay';
		return $methods;
	}//END-wc_add_gateway
	
	add_filter('woocommerce_payment_gateways', 'woocommerce_add_gateway_mintpay_gateway' );
	
} //END-init

/**
* 'Settings' link on plugin page
**/
add_filter( 'plugin_action_links', 'mintpay_add_action_plugin', 10, 5 );
function mintpay_add_action_plugin( $actions, $plugin_file ) {
	static $plugin;

	if (!isset($plugin))
		$plugin = plugin_basename(__FILE__);
	if ($plugin == $plugin_file) {

			$settings = array('settings' => '<a href="admin.php?page=wc-settings&tab=checkout&section=wc_gateway_mintpay">' . __('Settings') . '</a>');
		
    			$actions = array_merge($settings, $actions);
			
		}
		
		return $actions;
}//END-settings_add_action_link
